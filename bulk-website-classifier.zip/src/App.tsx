import React, { useState, useEffect, useRef } from "react";
import { 
  Upload, Play, Pause, RefreshCw, Download, Plus, Trash2, Settings, 
  Layers, Table, FileText, CheckCircle2, AlertTriangle, Search, 
  Building2, ExternalLink, Eye, Globe, Sparkles, Cpu, Check, 
  Hourglass, Info, X, HelpCircle, ArrowUpRight, MessageSquareCode
} from "lucide-react";
import { CompanyRow, CustomFieldConfig, DeploymentConfig } from "./types";

export default function App() {
  // -------------------------------------------------------------
  // States
  // -------------------------------------------------------------
  const [rows, setRows] = useState<CompanyRow[]>([]);
  const [customFields, setCustomFields] = useState<CustomFieldConfig[]>([
    { name: "SaaS Model", prompt: "Identify if the product operates on a SaaS Subscription model (Yes/No with quick reason)." },
    { name: "Estimated Competitors", prompt: "List 2 potential direct corporate competitors." }
  ]);
  const [customInstructions, setCustomInstructions] = useState<string>("");
  const [concurrency, setConcurrency] = useState<number>(2);
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [selectedRow, setSelectedRow] = useState<CompanyRow | null>(null);
  
  // Drag & Drop
  const [dragActive, setDragActive] = useState<boolean>(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Runtime Tracking
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [activeThreads, setActiveThreads] = useState<number>(0);
  const [consoleLogs, setConsoleLogs] = useState<{ id: string; time: string; text: string; type: "info" | "success" | "warning" | "error" }[]>([
    { id: "init", time: new Date().toLocaleTimeString(), text: "System ready. Upload a CSV or seed sample companies to begin bulk classification.", type: "info" }
  ]);
  
  // Diagnostic state for backend Gemini key checking
  const [diagnostic, setDiagnostic] = useState<{ geminiKeyConfigured: boolean; appUrl: string } | null>(null);

  // Manual Add Form
  const [manualName, setManualName] = useState("");
  const [manualUrl, setManualUrl] = useState("");

  const isRunningRef = useRef(isRunning);
  const rowsRef = useRef(rows);

  // Sync refs to avoid closures in async loop
  useEffect(() => {
    isRunningRef.current = isRunning;
  }, [isRunning]);

  useEffect(() => {
    rowsRef.current = rows;
  }, [rows]);

  // Load state from localStorage on init
  useEffect(() => {
    try {
      const savedRows = localStorage.getItem("site_classifier_rows");
      if (savedRows) {
        setRows(JSON.parse(savedRows));
      }
      const savedFields = localStorage.getItem("site_classifier_fields");
      if (savedFields) {
        setCustomFields(JSON.parse(savedFields));
      }
      const savedInstructions = localStorage.getItem("site_classifier_inst");
      if (savedInstructions) {
        setCustomInstructions(savedInstructions);
      }
    } catch (e) {
      console.error("Local storage sync error", e);
    }

    // Fetch diagnostics
    fetch("/api/config")
      .then(res => res.json())
      .then((data) => setDiagnostic(data))
      .catch((err) => console.error("Error launching diagnostic config check:", err));
  }, []);

  // Save states on change
  const saveRows = (newRows: CompanyRow[]) => {
    setRows(newRows);
    localStorage.setItem("site_classifier_rows", JSON.stringify(newRows));
  };

  const saveFields = (newFields: CustomFieldConfig[]) => {
    setCustomFields(newFields);
    localStorage.setItem("site_classifier_fields", JSON.stringify(newFields));
  };

  // Log logger
  const addLog = (text: string, type: "info" | "success" | "warning" | "error" = "info") => {
    setConsoleLogs(prev => [
      {
        id: Math.random().toString(),
        time: new Date().toLocaleTimeString(),
        text,
        type
      },
      ...prev.slice(0, 79) // limits to latest 80 logs
    ]);
  };

  // -------------------------------------------------------------
  // Data Handlers & Seeds
  // -------------------------------------------------------------
  const seedSampleData = () => {
    const samples: CompanyRow[] = [
      { id: "1", name: "Stripe", website: "stripe.com", status: "idle" },
      { id: "2", name: "Airbnb", website: "airbnb.com", status: "idle" },
      { id: "3", name: "Vercel", website: "vercel.com", status: "idle" },
      { id: "4", name: "Shopify", website: "shopify.com", status: "idle" },
      { id: "5", name: "Supabase", website: "supabase.com", status: "idle" },
      { id: "6", name: "Webflow", website: "webflow.com", status: "idle" }
    ];
    saveRows(samples);
    addLog("Seeded 6 sample global technology companies successfully.", "success");
  };

  const handleManualAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualName.trim() && !manualUrl.trim()) return;
    
    // Auto format URL nicely
    let formattedUrl = manualUrl.trim();
    if (formattedUrl && !/^https?:\/\//i.test(formattedUrl)) {
      formattedUrl = formattedUrl; // stored as is, backend will prepend https
    }

    const newRow: CompanyRow = {
      id: Date.now().toString(),
      name: manualName.trim() || formattedUrl.replace(/https?:\/\/(www\.)?/, "").split("/")[0],
      website: formattedUrl,
      status: "idle"
    };

    saveRows([...rows, newRow]);
    setManualName("");
    setManualUrl("");
    addLog(`Manually queued company "${newRow.name}" for analysis.`, "info");
  };

  const handleClearAll = () => {
    if (confirm("Are you sure you want to clear your current workspace? You will lose any current scraped results.")) {
      saveRows([]);
      setSelectedRow(null);
      setIsRunning(false);
      addLog("Cleared workspace environment.", "warning");
    }
  };

  // CSV Parsing
  const processCSVText = (text: string) => {
    try {
      const lines = text.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
      if (lines.length === 0) {
        addLog("Uploaded CSV appears to be empty.", "error");
        return;
      }

      // Quoted commas parsing helper
      const parseLine = (line: string): string[] => {
        const cols: string[] = [];
        let cur = "";
        let inQ = false;
        for (let i = 0; i < line.length; i++) {
          const char = line[i];
          if (char === '"') {
            inQ = !inQ;
          } else if (char === ',' && !inQ) {
            cols.push(cur.trim().replace(/^"|"$/g, '').trim());
            cur = "";
          } else {
            cur += char;
          }
        }
        cols.push(cur.trim().replace(/^"|"$/g, '').trim());
        return cols;
      };

      const headers = parseLine(lines[0]);
      let nameIndex = 0;
      let webIndex = 1;
      let foundHeaders = false;

      headers.forEach((h, idx) => {
        const lh = h.toLowerCase();
        if (lh.includes("company") || lh.includes("name") || lh.includes("brand")) {
          nameIndex = idx;
          foundHeaders = true;
        }
        if (lh.includes("web") || lh.includes("url") || lh.includes("domain") || lh.includes("site") || lh.includes("link")) {
          webIndex = idx;
          foundHeaders = true;
        }
      });

      const startIndex = foundHeaders ? 1 : 0;
      const parsedRows: CompanyRow[] = [];

      for (let i = startIndex; i < lines.length; i++) {
        const cols = parseLine(lines[i]);
        if (cols.length === 0) continue;
        const nameVal = cols[nameIndex] || "";
        const webVal = cols[webIndex] || cols[0] || "";
        if (nameVal || webVal) {
          parsedRows.push({
            id: `${Date.now()}-${i}-${Math.random().toString(36).substring(2, 5)}`,
            name: nameVal || webVal.replace(/https?:\/\/(www\.)?/, "").split("/")[0],
            website: webVal,
            status: "idle"
          });
        }
      }

      if (parsedRows.length > 0) {
        saveRows([...rows, ...parsedRows]);
        addLog(`Imported ${parsedRows.length} corporate items from CSV file. Header auto-detection was ${foundHeaders ? 'Successful' : 'Skipped'} (Mapped Name to column ${nameIndex + 1}, Website to column ${webIndex + 1}).`, "success");
      } else {
        addLog("No valid rows could be parsed from the uploaded file.", "error");
      }
    } catch (e: any) {
      addLog(`Failed reading CSV: ${e.message}`, "error");
    }
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      if (file.name.endsWith(".csv") || file.type === "text/csv") {
        const reader = new FileReader();
        reader.onload = (event) => {
          const text = event.target?.result as string;
          processCSVText(text);
        };
        reader.readAsText(file);
      } else {
        addLog("Please upload a standard extension .csv file only.", "error");
      }
    }
  };

  const handleFiles = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const reader = new FileReader();
      reader.onload = (event) => {
        const text = event.target?.result as string;
        processCSVText(text);
      };
      reader.readAsText(file);
    }
  };

  // -------------------------------------------------------------
  // Custom Fields Schema modifiers
  // -------------------------------------------------------------
  const addCustomField = () => {
    const fieldName = prompt("Enter enriched column header name (e.g., 'Target Industry Keywords', 'Annual Revenue Estimate'):");
    if (!fieldName) return;
    const cleanFieldName = fieldName.trim();
    if (customFields.some(f => f.name.toLowerCase() === cleanFieldName.toLowerCase())) {
      alert("A column with this name already exists.");
      return;
    }
    const fieldPrompt = prompt(`Define the extraction rule prompt instructions for Gemini for column "${cleanFieldName}":\n(e.g., "Look up the web context and guess their approximate employee count")`);
    if (!fieldPrompt) return;

    const updated = [...customFields, { name: cleanFieldName, prompt: fieldPrompt.trim() }];
    saveFields(updated);
    addLog(`Configured dynamic AI enrichment column: "${cleanFieldName}"`, "info");
  };

  const removeCustomField = (index: number) => {
    const updated = [...customFields];
    const removed = updated.splice(index, 1)[0];
    saveFields(updated);
    addLog(`Deleted enrichment column "${removed.name}".`, "warning");
  };

  // -------------------------------------------------------------
  // Bulk Classification Queue Logic
  // -------------------------------------------------------------
  const processSingleRow = async (row: CompanyRow): Promise<CompanyRow> => {
    try {
      const reqBody = {
        companyName: row.name,
        url: row.website,
        customFields: customFields,
        customInstructions: customInstructions
      };

      const res = await fetch("/api/classify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(reqBody)
      });

      if (!res.ok) {
        const errJson = await res.json().catch(() => ({}));
        throw new Error(errJson.error || `HTTP ${res.status} response from enrichment gateway.`);
      }

      const body = await res.json();
      if (!body.success) {
        throw new Error(body.error || "Gemini classification returned false state.");
      }

      const rawAi = body.data;
      
      // Remap the customFields list returned from server to record dictionary
      const fieldsDict: Record<string, string> = {};
      if (rawAi.customFields && Array.isArray(rawAi.customFields)) {
        rawAi.customFields.forEach((cf: { columnName: string; value: string }) => {
          fieldsDict[cf.columnName] = cf.value;
        });
      }

      return {
        ...row,
        status: "completed",
        error: null,
        enrichedName: rawAi.companyName,
        enrichedWebsite: rawAi.url,
        industry: rawAi.industry,
        subIndustry: rawAi.subIndustry,
        description: rawAi.description,
        stageOrSize: rawAi.stageOrSize,
        targetAudience: rawAi.targetAudience,
        mainProduct: rawAi.mainProduct,
        techStackTags: rawAi.techStackTags,
        pricingModel: rawAi.pricingModel,
        confidenceScore: rawAi.confidenceScore,
        customFields: fieldsDict,
        scrapeReport: body.scrapeReport || null
      };

    } catch (err: any) {
      console.error(`Error with website classification row ${row.name}:`, err);
      return {
        ...row,
        status: "failed",
        error: err.message || String(err),
        scrapeReport: {
          attempted: true,
          directScrapeOk: false,
          directTitle: "",
          directError: err.message || "Failed to process"
        }
      };
    }
  };

  // Sequential batch executor respecting concurrency settings
  const runBatchQueue = async () => {
    if (!isRunningRef.current) return;

    // Grab rows matching criteria (pending or previously failed that need rewrite)
    const currentRows = [...rowsRef.current];
    const pendingRows = currentRows.filter(r => r.status === "idle" || r.status === "processing");
    
    if (pendingRows.length === 0) {
      addLog("All pending companies completed classification.", "success");
      setIsRunning(false);
      return;
    }

    addLog(`Running bulk execution pipeline. Remaining queue length: ${pendingRows.length}`, "info");

    let itemsLeft = [...pendingRows];
    const activePromises: Promise<void>[] = [];

    // Worker threads loop
    const spawnWorker = async () => {
      while (itemsLeft.length > 0 && isRunningRef.current) {
        const itemToProcess = itemsLeft.shift();
        if (!itemToProcess) break;

        // Set status to processing
        setRows(prev => prev.map(r => r.id === itemToProcess.id ? { ...r, status: "processing" } : r));
        setActiveThreads(prev => prev + 1);

        addLog(`Initiating scrape and search mapping for: ${itemToProcess.name || itemToProcess.website}...`, "info");
        
        const outputRow = await processSingleRow(itemToProcess);

        // Save row result
        setRows(prev => {
          const updated = prev.map(r => r.id === itemToProcess.id ? outputRow : r);
          localStorage.setItem("site_classifier_rows", JSON.stringify(updated));
          return updated;
        });

        // Update active modal selected detail if open
        setSelectedRow(currentSelected => {
          if (currentSelected?.id === itemToProcess.id) {
            return outputRow;
          }
          return currentSelected;
        });

        if (outputRow.status === "completed") {
          addLog(`Successful Enriched [${itemToProcess.name}]: mapped to ${outputRow.industry} (${outputRow.subIndustry}) with ${(outputRow.confidenceScore || 0) * 100}% confidence.`, "success");
        } else {
          addLog(`Failed processing [${itemToProcess.name}]: ${outputRow.error}`, "error");
        }

        setActiveThreads(prev => Math.max(0, prev - 1));
      }
    };

    // Spawn up to configured limit
    const poolSize = Math.min(concurrency, pendingRows.length);
    for (let i = 0; i < poolSize; i++) {
      activePromises.push(spawnWorker());
    }

    await Promise.all(activePromises);
    
    // Check if fully finished
    const finalRows = rowsRef.current;
    if (finalRows.filter(r => r.status === "idle" || r.status === "processing").length === 0) {
      addLog("Bulk processing completely finished.", "success");
      setIsRunning(false);
    }
  };

  // Launch controller
  useEffect(() => {
    if (isRunning) {
      runBatchQueue();
    } else {
      setActiveThreads(0);
    }
  }, [isRunning]);

  const handleStartClassification = () => {
    if (rows.length === 0) {
      alert("Please upload a CSV or manually queue a few company URLs to classify first.");
      return;
    }

    if (!diagnostic?.geminiKeyConfigured) {
      addLog("Cannot initiate classification. Your GEMINI_API_KEY environment secret is missing. Enter AI Studio Secrets manager to provision yours.", "error");
      alert("Missing GEMINI_API_KEY. Please verify or configure your secret inside settings before launching classifying pipeline.");
      return;
    }

    // Reset failed/idle states before running so they re-trigger
    const recooled = rows.map(r => r.status === "failed" ? { ...r, status: "idle" as const } : r);
    setRows(recooled);
    rowsRef.current = recooled;

    setIsRunning(true);
    addLog(`Engaged processing threads. Concurrency: ${concurrency} units.`, "success");
  };

  const handlePauseClassification = () => {
    setIsRunning(false);
    addLog("Paused bulk scraper threads. Active processes will finalize current task.", "warning");
  };

  const handleResetRowStatus = (rowId: string) => {
    const updated = rows.map(r => r.id === rowId ? { ...r, status: "idle" as const, error: null } : r);
    saveRows(updated);
    addLog("Reset row state for re-scriping.", "info");
  };

  const handleDeleteRow = (rowId: string) => {
    const updated = rows.filter(r => r.id !== rowId);
    saveRows(updated);
    if (selectedRow?.id === rowId) setSelectedRow(null);
    addLog("Removed row from workspace.", "info");
  };

  // CSV Generator Downloader
  const downloadEnrichedCSV = () => {
    if (rows.length === 0) return;

    // Define Header columns
    const headers = [
      "Original Target Name",
      "Entered Website URL",
      "AI Validated Name",
      "AI Validated Domain",
      "Industry Sector",
      "Niche Speciality",
      "One Sentence Business Proposition",
      "Estimated Maturity",
      "Core Audience",
      "Primary Product",
      "Inferred Pricing System",
      "Identified Tech Keywords",
      "AI Confidence Index",
      "Scraping Status"
    ];

    // Append dynamic columns
    customFields.forEach(f => {
      headers.push(f.name);
    });

    const escapeCSV = (val: string | undefined | null | string[]) => {
      if (val === undefined || val === null) return '""';
      const textVal = Array.isArray(val) ? val.join(" | ") : String(val);
      const escaped = textVal.replace(/"/g, '""');
      return `"${escaped}"`;
    };

    const lines = [headers.join(",")];

    rows.forEach(r => {
      const line = [
        escapeCSV(r.name),
        escapeCSV(r.website),
        escapeCSV(r.enrichedName || ""),
        escapeCSV(r.enrichedWebsite || ""),
        escapeCSV(r.industry || ""),
        escapeCSV(r.subIndustry || ""),
        escapeCSV(r.description || ""),
        escapeCSV(r.stageOrSize || ""),
        escapeCSV(r.targetAudience || ""),
        escapeCSV(r.mainProduct || ""),
        escapeCSV(r.pricingModel || ""),
        escapeCSV(r.techStackTags || []),
        escapeCSV(r.confidenceScore !== undefined ? r.confidenceScore.toFixed(3) : ""),
        escapeCSV(r.scrapeReport?.directScrapeOk ? "Direct HTML Scrape OK" : r.scrapeReport?.directError || "Search Grounded Fallback")
      ];

      // Custom enrichments
      customFields.forEach(f => {
        const value = r.customFields?.[f.name] || "";
        line.push(escapeCSV(value));
      });

      lines.push(line.join(","));
    });

    const csvContent = lines.join("\n");
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `enriched_companies_pipeline_${new Date().toISOString().split("T")[0]}.csv`;
    link.style.display = "none";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    addLog("Exported corporate master sheet as structured CSV file.", "success");
  };

  // Filter Table entries
  const filteredRows = rows.filter(r => {
    const q = searchQuery.toLowerCase();
    return (
      r.name.toLowerCase().includes(q) ||
      r.website.toLowerCase().includes(q) ||
      (r.industry && r.industry.toLowerCase().includes(q)) ||
      (r.subIndustry && r.subIndustry.toLowerCase().includes(q)) ||
      (r.description && r.description.toLowerCase().includes(q))
    );
  });

  // Performance calculations
  const totalCount = rows.length;
  const completedCount = rows.filter(r => r.status === "completed").length;
  const failedCount = rows.filter(r => r.status === "failed").length;
  const activeCount = rows.filter(r => r.status === "processing").length;
  const idleCount = rows.filter(r => r.status === "idle").length;
  
  const progressPercent = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;
  const averageConfidence = completedCount > 0 
    ? rows.filter(r => r.status === "completed" && r.confidenceScore).reduce((sum, r) => sum + (r.confidenceScore || 0), 0) / completedCount 
    : 0;

  return (
    <div className="min-h-screen bg-[#f8fafc] text-slate-900 font-sans flex flex-col antialiased">
      {/* -------------------------------------------------------------
          Primary Workspace Header
         ------------------------------------------------------------- */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-10 px-6 py-4 shadow-sm">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-indigo-600 rounded-lg flex items-center justify-center text-white shrink-0 shadow-sm">
              <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" x2="12" y1="3" y2="15"/></svg>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-bold tracking-tight text-slate-900">BulkEnrich AI</h1>
                <span className="text-[10px] tracking-wider font-bold bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded-full border border-indigo-100 uppercase">Gemini Active</span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">Automated CSV Scraper &amp; Gemini AI Search Grounded Market Enricher</p>
            </div>
          </div>

          <div className="flex items-center gap-3 flex-wrap">
            {/* Server diagnostics */}
            {diagnostic ? (
              <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-50 border border-slate-200 text-xs shadow-3xs">
                <span className={`w-2 h-2 rounded-full ${diagnostic.geminiKeyConfigured ? 'bg-emerald-500 animate-pulse' : 'bg-amber-500 animate-pulse'}`}></span>
                <span className="font-mono text-slate-600 font-medium">
                  {diagnostic.geminiKeyConfigured ? "Engine: Stable" : "API Secret: Missing"}
                </span>
                {!diagnostic.geminiKeyConfigured && (
                  <div className="group relative">
                    <HelpCircle className="w-3.5 h-3.5 text-amber-600 hover:text-amber-800 cursor-help" />
                    <div className="absolute right-0 top-6 hidden group-hover:block bg-slate-900 text-white p-3 rounded-lg text-xs w-64 shadow-xl leading-relaxed z-30">
                      Please enter your <strong className="text-indigo-400">GEMINI_API_KEY</strong> inside the <strong>Secrets Settings Panel</strong> of your AI Studio Workspace.
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="flex items-center gap-2 bg-slate-50 px-3 py-1.5 rounded-lg text-xs animate-pulse border border-slate-200">
                <RefreshCw className="w-3.5 h-3.5 animate-spin text-slate-400" />
                <span className="text-slate-400 font-mono">Verifying engine...</span>
              </div>
            )}

            {rows.length > 0 && (
              <button
                id="export-csv-btn"
                onClick={downloadEnrichedCSV}
                className="flex items-center gap-1.5 bg-indigo-600 hover:bg-indigo-700 active:scale-98 text-white px-4 py-2 rounded-lg text-xs font-semibold shadow-xs transition-colors cursor-pointer"
              >
                <Download className="w-4 h-4" /> Download Clean CSV ({rows.length})
              </button>
            )}
          </div>
        </div>
      </header>

      {/* -------------------------------------------------------------
          Workspace Layout Core
         ------------------------------------------------------------- */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-6 py-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Side: Setup & Enrichment Specifications (lg:col-span-4) */}
        <section className="lg:col-span-4 flex flex-col gap-6" id="setup-panel">
          
          {/* CSV File Drag Drop Dropzone */}
          <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-sm flex flex-col gap-4">
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block font-sans">Input Source</label>
            
            <div
              onDragEnter={handleDrag}
              onDragOver={handleDrag}
              onDragLeave={handleDrag}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className={`border border-dashed rounded-lg p-5 flex flex-col items-center justify-center text-center cursor-pointer transition-all ${
                dragActive 
                  ? "border-indigo-500 bg-indigo-50/40 scale-[0.99] shadow-inner" 
                  : "border-slate-300 bg-slate-50/50 hover:bg-[#f8fafc] hover:border-indigo-400"
              }`}
            >
              <input
                ref={fileInputRef}
                type="file"
                accept=".csv"
                onChange={handleFiles}
                className="hidden"
              />
              <FileText className="w-8 h-8 text-indigo-500 mb-2 opacity-80" />
              <p className="text-xs font-semibold text-slate-800">Drag &amp; drop company CSV here</p>
              <span className="text-[10px] text-slate-400 mt-1">Or click to browse storage files</span>
              <span className="text-[9px] text-indigo-600 bg-indigo-50/50 border border-indigo-100 px-2 py-0.5 rounded mt-2.5 font-sans font-medium">Looks for "name" &amp; "website" headers</span>
            </div>

            <div className="flex items-center gap-2 my-1">
              <div className="h-[1px] bg-slate-200 flex-1"></div>
              <span className="text-[10px] uppercase tracking-wider text-slate-400 font-bold">OR Manual entry</span>
              <div className="h-[1px] bg-slate-200 flex-1"></div>
            </div>

            {/* Manual Form */}
            <form onSubmit={handleManualAdd} className="flex flex-col gap-2">
              <div>
                <input
                  type="text"
                  placeholder="Enter Company Name (e.g. OpenAI)"
                  value={manualName}
                  onChange={(e) => setManualName(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-250 rounded-lg text-xs focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-hidden transition-all text-slate-800 placeholder:text-slate-400"
                />
              </div>
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="Website URL (e.g. openai.com)"
                  value={manualUrl}
                  onChange={(e) => setManualUrl(e.target.value)}
                  className="flex-1 px-3 py-2 bg-white border border-slate-250 rounded-lg text-xs focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-hidden transition-all text-slate-800 placeholder:text-slate-400"
                />
                <button
                  type="submit"
                  className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg text-xs font-semibold shadow-xs active:scale-95 transition-all cursor-pointer shrink-0"
                >
                  Add
                </button>
              </div>
            </form>

            {/* Quick Seeds */}
            <div className="bg-slate-50 border border-slate-200 rounded-lg p-3.5 flex flex-col gap-1.5 mt-1">
              <div className="flex justify-between items-center">
                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">Test Playground</span>
                <span className="text-[9px] font-semibold text-emerald-700 bg-emerald-100/85 px-1.5 py-0.5 rounded">Fast Demo</span>
              </div>
              <p className="text-[11px] text-slate-500 leading-relaxed">No CSV on hand? Seed immediate premier target data models to verify real-time search extraction.</p>
              <button
                type="button"
                onClick={seedSampleData}
                placeholder="Seed Data"
                className="w-full mt-1 bg-indigo-50 border border-indigo-100 hover:bg-indigo-100 text-indigo-700 py-1.5 rounded-md text-[11px] font-semibold flex items-center justify-center gap-1 cursor-pointer transition-colors shadow-xs"
              >
                <Sparkles className="w-3.5 h-3.5 text-indigo-500" /> Populate 6 Sample Tech Companies
              </button>
            </div>
          </div>

          {/* Dynamic AI Enrichment Variables Column configuration */}
          <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-sm flex flex-col gap-4">
            <div className="flex items-center justify-between">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block font-sans">Processing Pipeline Setup</label>
              <button
                type="button"
                onClick={addCustomField}
                className="text-indigo-600 hover:text-white border border-indigo-200 hover:bg-indigo-600 p-1.5 rounded-lg transition-all cursor-pointer shadow-2xs"
                title="Add Enriched Column"
              >
                <Plus className="w-3.5 h-3.5" />
              </button>
            </div>

            <p className="text-xs text-slate-500 leading-relaxed">
              Define custom parameters you want Gemini to extract from real-time scraped web data:
            </p>

            {customFields.length === 0 ? (
              <div className="border border-dashed border-slate-200 rounded-lg p-4 text-center text-xs text-slate-400">
                No custom AI columns. Gemini will run default standard taxonomy classifications only.
              </div>
            ) : (
              <div className="flex flex-col gap-3">
                {customFields.map((field, idx) => (
                  <div key={idx} className="bg-[#f8fafc] border border-slate-200 rounded-lg p-3 relative hover:shadow-xs transition-shadow">
                    <button
                      type="button"
                      onClick={() => removeCustomField(idx)}
                      className="absolute top-2.5 right-2.5 text-slate-400 hover:text-rose-600 p-1 rounded-sm"
                      title="Delete variable"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                    <div className="text-xs font-semibold text-slate-900 flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-indigo-500"></span>
                      {field.name}
                    </div>
                    <div className="text-[11px] text-slate-500 mt-1.5 pr-6 leading-relaxed bg-white border border-slate-100 p-2 rounded-md font-sans">
                      <span className="font-mono text-[9px] text-slate-450 font-bold uppercase tracking-wider block mb-0.5">Prompt Rule:</span>
                      {field.prompt}
                    </div>
                  </div>
                ))}
              </div>
            )}
            
            {/* Custom AI Instructions */}
            <div className="flex flex-col gap-1.5">
              <label className="text-[11px] font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1">
                <MessageSquareCode className="w-3.5 h-3.5 text-indigo-500" /> Global Pipeline Prompt Guide (Optional)
              </label>
              <textarea
                placeholder="e.g. Focus on identifying whether they support open-weights models. Be concise."
                value={customInstructions}
                onChange={(e) => {
                  setCustomInstructions(e.target.value);
                  localStorage.setItem("site_classifier_inst", e.target.value);
                }}
                className="w-full h-16 min-h-16 max-h-24 px-3 py-2 bg-white border border-slate-250 rounded-lg text-xs focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-hidden font-mono transition-all text-slate-800 placeholder:text-slate-400"
              />
            </div>

            {/* Concurrency Settings */}
            <div className="flex flex-col gap-2 mt-2 pt-3 border-t border-slate-100">
              <div className="flex justify-between items-center text-xs">
                <span className="font-bold text-slate-700 flex items-center gap-1">
                  <Settings className="w-3.5 h-3.5 text-indigo-500" /> Scraper Concurrency
                </span>
                <span className="font-mono bg-indigo-55 text-indigo-700 px-2 py-0.5 rounded font-bold border border-indigo-100">{concurrency} Workers</span>
              </div>
              <input
                type="range"
                min="1"
                max="5"
                value={concurrency}
                onChange={(e) => setConcurrency(parseInt(e.target.value))}
                className="w-full accent-indigo-600 cursor-pointer h-1.5 bg-slate-250 rounded-lg appearance-none"
              />
              <span className="text-[10px] text-slate-400 leading-tight">Controls active parallel scraper workflows. Lower values provide better rate limiting on corporate websites.</span>
            </div>
          </div>
        </section>

        {/* Right Side: Data Board, Queue Management, Dataset & Logs (lg:col-span-8) */}
        <section className="lg:col-span-8 flex flex-col gap-6" id="dataset-panel">
          
          {/* Action Header and Queue Progress Widgets */}
          <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-sm flex flex-col gap-5">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
              <div>
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Execution Hub</label>
                <h2 className="text-base font-bold text-slate-900 tracking-tight">Active Scraper Pipeline Engine</h2>
                <p className="text-xs text-slate-500 mt-0.5">Control web harvesting and generative AI taxonomy pipelines directly.</p>
              </div>

              <div className="flex items-center gap-2">
                {rows.length > 0 && (
                  <button
                    onClick={handleClearAll}
                    className="flex items-center gap-1.5 border border-slate-200 text-slate-600 hover:bg-rose-50 hover:text-rose-700 hover:border-rose-350 px-3 py-2 rounded-lg text-xs font-semibold active:scale-95 transition-all cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" /> Reset Environment
                  </button>
                )}
                
                {isRunning ? (
                  <button
                    onClick={handlePauseClassification}
                    className="flex items-center gap-1.5 bg-amber-500 hover:bg-amber-600 text-white px-5 py-2.5 rounded-lg text-xs font-bold active:scale-95 transition-all shadow-sm cursor-pointer"
                  >
                    <div className="w-2 h-2 bg-white rounded-full animate-pulse mr-0.5"></div>
                    Pause Harvesting Threads
                  </button>
                ) : (
                  <button
                    onClick={handleStartClassification}
                    className="flex items-center gap-1.5 bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2.5 rounded-lg text-xs font-bold active:scale-[1.01] transition-all shadow-md cursor-pointer"
                  >
                    <Play className="w-4 h-4 animate-bounce" /> Start Bulk Pipeline
                  </button>
                )}
              </div>
            </div>

            {/* Performance Stats Cards Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-1">
              <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm border-l-4 border-l-slate-400 flex flex-col justify-between min-h-[96px]">
                <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Total Companies</span>
                <span className="text-2xl font-black text-slate-900 mt-1 font-sans">{totalCount}</span>
                <div className="text-[10px] text-slate-500 mt-1 flex items-center gap-1">
                  <Table className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  Loaded entries
                </div>
              </div>
              <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm border-l-4 border-l-indigo-500 flex flex-col justify-between min-h-[96px]">
                <span className="text-[10px] text-indigo-500 font-bold uppercase tracking-wider">Scraping Threads</span>
                <span className="text-2xl font-black text-indigo-900 mt-1 font-sans">
                  {activeCount} <span className="text-xs text-indigo-400 font-medium">/ {concurrency} active</span>
                </span>
                <div className="text-[10px] text-indigo-600 mt-1 flex items-center gap-1 font-medium">
                  {activeCount > 0 ? (
                    <span className="flex items-center gap-1">
                      <RefreshCw className="w-3 h-3 animate-spin text-indigo-500" /> Web harvesting...
                    </span>
                  ) : (
                    <span>Workers ready</span>
                  )}
                </div>
              </div>
              <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm border-l-4 border-l-emerald-500 flex flex-col justify-between min-h-[96px]">
                <span className="text-[10px] text-emerald-600 font-bold uppercase tracking-wider">AI Classified</span>
                <span className="text-2xl font-black text-emerald-900 mt-1 font-sans">{completedCount}</span>
                <div className="text-[10px] text-emerald-700 mt-1 flex items-center gap-1 font-medium">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" /> Accuracy rating stable
                </div>
              </div>
              <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm border-l-4 border-l-rose-500 flex flex-col justify-between min-h-[96px]">
                <span className="text-[10px] text-rose-500 font-bold uppercase tracking-wider">Scrape Failures</span>
                <span className="text-2xl font-black text-rose-900 mt-1 font-sans">{failedCount}</span>
                <div className="text-[10px] text-rose-600 mt-1 flex items-center gap-1 font-medium">
                  {failedCount > 0 ? "Blocked corporate domains" : "Healthy proxy flow"}
                </div>
              </div>
            </div>

            {/* Total progress loading bar */}
            {totalCount > 0 && (
              <div className="mt-1 pt-1">
                <div className="flex justify-between items-center text-xs text-slate-500 mb-1.5">
                  <span className="font-semibold text-slate-600">Queue processing progress</span>
                  <span className="font-mono font-bold text-slate-700">{progressPercent}% ({completedCount} / {totalCount})</span>
                </div>
                <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden border border-slate-200/60">
                  <div
                    className="bg-indigo-600 h-full rounded-full transition-all duration-500"
                    style={{ width: `${progressPercent}%` }}
                  />
                </div>
                {completedCount > 0 && (
                  <div className="text-[10px] text-slate-500 mt-2 flex items-center gap-2">
                    <span className="flex items-center gap-0.5 font-semibold bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded border border-indigo-100 font-sans">
                      <Sparkles className="w-3 h-3 text-indigo-500" /> average confidence: {Math.round(averageConfidence * 100)}%
                    </span>
                    <span>•</span>
                    <span>Using search-grounding logic automatically for uncooperative corporate firewall blocks.</span>
                  </div>
                )}
              </div>
            )}
          </div>          {/* Core Table View Interface */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm flex flex-col min-h-[450px]">
            {/* Table Search Filters and Header */}
            <div className="px-5 py-4 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 bg-[#f8fafc] rounded-t-xl">
              <div className="flex items-center gap-2">
                <Table className="w-4 h-4 text-indigo-600" />
                <h3 className="text-xs font-bold text-slate-700 tracking-wider uppercase font-sans">LIVE OUTPUT PREVIEW ({filteredRows.length})</h3>
              </div>
              
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  placeholder="Filter by name, URL, industry..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-8 pr-4 py-1.5 w-full sm:w-64 bg-white border border-slate-250 rounded-lg text-xs focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-hidden transition-all text-slate-800 placeholder:text-slate-400"
                />
              </div>
            </div>

            {/* Dataset Grid Table frame */}
            <div className="flex-1 overflow-x-auto">
              {filteredRows.length === 0 ? (
                <div className="flex flex-col items-center justify-center p-12 text-center h-full">
                  <Building2 className="w-12 h-12 text-slate-300 mb-2.5" />
                  <p className="text-xs font-semibold text-slate-705 text-slate-600">No corporate targets present inside active state</p>
                  <p className="text-[11px] text-slate-400 max-w-sm mt-1">Upload a list of target links in CSV standard, write manual domain strings in the entry field, or seed mockup data matrices.</p>
                </div>
              ) : (
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-slate-200 text-[10px] font-bold text-slate-400 uppercase bg-[#f8fafc]/50">
                      <th className="py-3 px-4 w-28">Status</th>
                      <th className="py-3 px-4">Subject Company</th>
                      <th className="py-3 px-4">Primary Sector</th>
                      <th className="py-3 px-4">Target Audience</th>
                      <th className="py-3 px-4">Speciality Niche</th>
                      <th className="py-3 px-4 w-20 text-center">Confidence</th>
                      <th className="py-3 px-4 w-24 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-xs">
                    {filteredRows.map((row) => {
                      const isSelected = selectedRow?.id === row.id;
                      return (
                        <tr
                          key={row.id}
                          className={`hover:bg-[#f8fafc]/60 transition-colors group ${
                            isSelected ? "bg-indigo-50/30 font-medium" : ""
                          }`}
                        >
                          {/* Row Status Badge Column */}
                          <td className="py-3.5 px-4">
                            {row.status === "idle" && (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-slate-100 text-slate-600 border border-slate-200 uppercase tracking-wider">
                                <Hourglass className="w-2.5 h-2.5 text-slate-450" /> Idle
                              </span>
                            )}
                            {row.status === "processing" && (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-indigo-50 text-indigo-700 border border-indigo-150 leading-none">
                                <RefreshCw className="w-2.5 h-2.5 text-indigo-500 animate-spin" /> Harvesting
                              </span>
                            )}
                            {row.status === "completed" && (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-50 text-emerald-800 border border-emerald-155">
                                <Check className="w-2.5 h-2.5 text-emerald-600" /> Done
                              </span>
                            )}
                            {row.status === "failed" && (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-rose-50 text-rose-800 border border-rose-200" title={row.error || "Execution timeout"}>
                                <AlertTriangle className="w-2.5 h-2.5 text-rose-500" /> Failed
                              </span>
                            )}
                          </td>

                          {/* Company Name & website URL */}
                          <td className="py-3.5 px-4">
                            <div className="flex flex-col">
                              <span className="text-slate-900 font-bold tracking-tight text-xs flex items-center gap-1">
                                {row.enrichedName || row.name}
                                {row.scrapeReport?.directScrapeOk && (
                                  <span className="px-1.5 py-0.5 bg-indigo-50 text-indigo-700 rounded text-[8px] font-bold uppercase tracking-wider">Scraped</span>
                                )}
                              </span>
                              <a
                                href={row.website ? (row.website.startsWith("http") ? row.website : `https://${row.website}`) : "#"}
                                target="_blank"
                                rel="noreferrer"
                                className="text-[11px] text-indigo-600 hover:text-indigo-800 flex items-center gap-0.5 font-mono max-w-44 truncate"
                              >
                                {row.website} <ExternalLink className="w-2.5 h-2.5 inline opacity-0 group-hover:opacity-100 transition-opacity" />
                              </a>
                            </div>
                          </td>

                          {/* Primary sector category */}
                          <td className="py-3.5 px-4">
                            {row.industry ? (
                              <span className="text-slate-800 font-semibold">{row.industry}</span>
                            ) : (
                              <span className="text-slate-400 italic">No Data</span>
                            )}
                          </td>

                          {/* Target Audience */}
                          <td className="py-3.5 px-4">
                            {row.targetAudience ? (
                              <span className="bg-indigo-50/50 text-indigo-700 px-2 py-0.5 rounded text-[11px] font-medium border border-indigo-100/60 shadow-3xs">
                                {row.targetAudience}
                              </span>
                            ) : (
                              <span className="text-slate-400 italic">—</span>
                            )}
                          </td>

                          {/* Specialty subSector Niche */}
                          <td className="py-3.5 px-4">
                            <span className="text-slate-500 block max-w-44 truncate text-[11px]">
                              {row.subIndustry || "Pending AI scan"}
                            </span>
                          </td>

                          {/* Confidence Rating Bar */}
                          <td className="py-3.5 px-4 text-center font-mono">
                            {row.confidenceScore !== undefined ? (
                              <div className="flex flex-col items-center">
                                <span className={`font-bold ${
                                  row.confidenceScore >= 0.85 ? "text-emerald-700" : row.confidenceScore >= 0.6 ? "text-amber-700" : "text-slate-500"
                                }`}>
                                  {row.confidenceScore.toFixed(3)}
                                </span>
                                <div className="w-12 bg-slate-100 h-1 rounded-full overflow-hidden mt-0.5 border border-slate-200">
                                  <div 
                                    className={`h-full ${
                                      row.confidenceScore >= 0.85 ? "bg-emerald-500" : row.confidenceScore >= 0.6 ? "bg-amber-500" : "bg-slate-400"
                                    }`}
                                    style={{ width: `${row.confidenceScore * 100}%` }}
                                  />
                                </div>
                              </div>
                            ) : (
                              <span className="text-slate-400 italic font-sans">—</span>
                            )}
                          </td>

                          {/* Action Items Column */}
                          <td className="py-3.5 px-4 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              <button
                                onClick={() => setSelectedRow(row)}
                                className="p-1 px-2 border border-indigo-100 hover:bg-indigo-600 hover:text-white hover:border-indigo-600 text-indigo-600 bg-indigo-50/30 rounded-md transition-all flex items-center gap-1 cursor-pointer"
                                title="Inspect Scrape details"
                              >
                                <Eye className="w-3.5 h-3.5" /> <span className="text-[10px] font-semibold">Inspect</span>
                              </button>
                              
                              <button
                                onClick={() => handleResetRowStatus(row.id)}
                                className="p-1 hover:bg-slate-100 text-slate-400 hover:text-slate-950 rounded-md transition-colors cursor-pointer"
                                title="Reset status to Idle"
                                disabled={row.status === "processing"}
                              >
                                <RefreshCw className="w-3.5 h-3.5" />
                              </button>

                              <button
                                onClick={() => handleDeleteRow(row.id)}
                                className="p-1 hover:bg-rose-50 text-slate-400 hover:text-rose-600 rounded-md transition-colors cursor-pointer"
                                title="Delete Target"
                                disabled={row.status === "processing"}
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              )}
            </div>
          </div>

          {/* Real-time Streaming Action Logs Drawer */}
          <div className="bg-[#0b0f19] rounded-xl p-5 text-slate-300 border border-[#161d30] font-mono shadow-md">
            <div className="flex justify-between items-center mb-3">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2 font-sans">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                Real-time pipeline logs
              </span>
              <span className="text-[9px] font-mono text-indigo-400 bg-indigo-950/60 border border-indigo-900/60 px-2 py-0.5 rounded">AUTO-REFRESH</span>
            </div>
            
            <div className="h-28 overflow-y-auto flex flex-col-reverse divide-y divide-[#151d30]/40 text-[10px] leading-relaxed select-text">
              {consoleLogs.map((log) => (
                <div key={log.id} className="py-2.5 flex gap-2">
                  <span className="text-slate-500 shrink-0 font-bold font-mono">[{log.time}]</span>
                  <span className={`
                    ${log.type === "success" ? "text-emerald-400" : ""}
                    ${log.type === "warning" ? "text-amber-400" : ""}
                    ${log.type === "error" ? "text-rose-400 font-bold" : ""}
                    ${log.type === "info" ? "text-slate-300" : ""}
                  `}>
                    {log.text}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </section>
      </main>

      {/* -------------------------------------------------------------
          Inspect Side-Drawer / Modal Detail Presentation Layer (Floating)
         ------------------------------------------------------------- */}
      {selectedRow && (
        <section className="fixed inset-0 bg-slate-900/30 backdrop-blur-xs flex items-center justify-end z-20" id="detail-drawer">
          <div className="bg-white w-full max-w-md h-full shadow-2xl flex flex-col text-slate-800 animate-slide-in p-6 relative border-l border-slate-250">
            
            {/* Drawer Close Trigger */}
            <button
              id="close-drawer-btn"
              onClick={() => setSelectedRow(null)}
              className="absolute top-5 right-5 p-1.5 hover:bg-slate-100 rounded-lg text-slate-400 hover:text-slate-900 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Entity Header */}
            <div className="flex items-center gap-2.5 mb-5 pr-10 mt-1">
              <div className="w-10 h-10 bg-indigo-50 border border-indigo-100 rounded-lg flex items-center justify-center text-indigo-600 shadow-3xs shrink-0">
                <Building2 className="w-5 h-5" />
              </div>
              <div className="truncate">
                <h3 className="text-base font-bold tracking-tight text-slate-900">{selectedRow.enrichedName || selectedRow.name}</h3>
                <a
                  href={selectedRow.website ? (selectedRow.website.startsWith("http") ? selectedRow.website : `https://${selectedRow.website}`) : undefined}
                  target="_blank"
                  rel="noreferrer"
                  className="text-xs text-indigo-600 hover:text-indigo-800 flex items-center gap-0.5 truncate font-mono mt-0.5"
                >
                  {selectedRow.website} <ArrowUpRight className="w-3 h-3 inline" />
                </a>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto flex flex-col gap-5 pr-2">
              
              {/* Classification Status banner */}
              <div>
                <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400 block mb-1">Status Analysis</span>
                <div className="bg-[#f8fafc] border border-slate-200 rounded-lg p-3">
                  <div className="flex justify-between items-center text-xs">
                    <span className="font-semibold text-slate-600">Classification Engine</span>
                    
                    {selectedRow.status === "idle" && <span className="text-slate-500 font-bold uppercase text-[10px] tracking-wider bg-slate-100 px-2 py-0.5 rounded">Idle Queue</span>}
                    {selectedRow.status === "processing" && <span className="text-indigo-600 font-bold animate-pulse uppercase text-[10px] tracking-wider bg-indigo-50 border border-indigo-100 px-2 py-0.5 rounded">Running Scrapers</span>}
                    {selectedRow.status === "completed" && <span className="text-emerald-700 font-bold flex items-center gap-1 uppercase text-[10px] tracking-wider bg-emerald-50 border border-emerald-100 px-2 py-0.5 rounded"><CheckCircle2 className="w-3.5 h-3.5" /> Mapped</span>}
                    {selectedRow.status === "failed" && <span className="text-rose-600 font-bold uppercase text-[10px] tracking-wider bg-rose-50 border border-rose-100 px-2 py-0.5 rounded">Failed</span>}
                  </div>

                  {selectedRow.scrapeReport?.attempted && (
                    <div className="mt-2.5 pt-2 border-t border-slate-150 flex flex-col gap-1 text-[11px] text-slate-500">
                      <div className="flex justify-between">
                        <span>Direct HTML Scrape:</span>
                        <span className={selectedRow.scrapeReport.directScrapeOk ? 'text-emerald-600 font-semibold' : 'text-amber-600 font-medium'}>
                          {selectedRow.scrapeReport.directScrapeOk ? 'SUCCESS' : 'Blocked / Search Grounded'}
                        </span>
                      </div>
                      {selectedRow.scrapeReport.directTitle && (
                        <div className="bg-white p-2 rounded border border-slate-200 mt-1">
                          <span className="font-mono text-[9px] text-slate-450 font-bold uppercase tracking-wider block">Homepage Title:</span>
                          <span className="italic block mt-0.5 text-slate-700">"{selectedRow.scrapeReport.directTitle}"</span>
                        </div>
                      )}
                      {selectedRow.scrapeReport.directError && (
                        <div className="text-slate-500 text-[10px] bg-slate-100 p-2 rounded border border-slate-200 mt-1 leading-snug">
                          <strong>Scraper Note:</strong> {selectedRow.scrapeReport.directError}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>

              {/* Business Description block */}
              <div>
                <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400 block mb-1">Corporate Mission</span>
                <p className="text-xs bg-[#f8fafc] p-3 rounded-lg border border-slate-200 text-slate-700 leading-relaxed">
                  {selectedRow.description || "Website scraping statistics have not compiled for this target company yet."}
                </p>
              </div>

              {/* Executive Metadata Metrics */}
              <div>
                <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400 block mb-1.5">Executive Metrics</span>
                <div className="grid grid-cols-2 gap-35">
                  <div className="bg-[#f8fafc] border border-slate-200 rounded-lg p-3">
                    <span className="text-[9px] text-indigo-600 font-bold block bg-indigo-50 border border-indigo-100 px-1.5 py-0.5 rounded w-max uppercase mb-1">Sector</span>
                    <span className="text-xs text-slate-900 font-bold">{selectedRow.industry || "—"}</span>
                  </div>
                  <div className="bg-[#f8fafc] border border-slate-200 rounded-lg p-3">
                    <span className="text-[9px] text-indigo-600 font-bold block bg-indigo-50 border border-indigo-100 px-1.5 py-0.5 rounded w-max uppercase mb-1">Sub Niche</span>
                    <span className="text-xs text-slate-900 font-bold">{selectedRow.subIndustry || "—"}</span>
                  </div>
                  <div className="bg-[#f8fafc] border border-slate-200 rounded-lg p-3">
                    <span className="text-[9px] text-slate-500 font-bold block bg-white border border-slate-200 px-1.5 py-0.5 rounded w-max uppercase mb-1">Maturity Scale</span>
                    <span className="text-xs text-slate-900 font-bold">{selectedRow.stageOrSize || "—"}</span>
                  </div>
                  <div className="bg-[#f8fafc] border border-slate-200 rounded-lg p-3">
                    <span className="text-[9px] text-slate-500 font-bold block bg-white border border-slate-200 px-1.5 py-0.5 rounded w-max uppercase mb-1">Pricing Scheme</span>
                    <span className="text-xs text-slate-900 font-bold">{selectedRow.pricingModel || "—"}</span>
                  </div>
                </div>
              </div>

              {/* Technologies Tag list */}
              <div>
                <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400 block mb-1.5">Identified Tech Profile</span>
                {selectedRow.techStackTags && selectedRow.techStackTags.length > 0 ? (
                  <div className="flex flex-wrap gap-1.5 animate-pulse-slow">
                    {selectedRow.techStackTags.map((tag, i) => (
                      <span key={i} className="bg-indigo-50 border border-indigo-100 text-indigo-700 text-[11px] px-2 py-0.5 rounded font-semibold font-mono">
                        {tag}
                      </span>
                    ))}
                  </div>
                ) : (
                  <span className="text-xs text-slate-400 italic">No technology profiles indexed.</span>
                )}
              </div>

              {/* Custom AI Enrichments answers */}
              <div>
                <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400 block mb-1.5">Enriched AI Columns</span>
                {customFields.length === 0 ? (
                  <span className="text-xs text-slate-400 italic font-sans">Configure Custom Columns on the left bar and rerun classification to enrich custom metrics.</span>
                ) : (
                  <div className="flex flex-col gap-2.5">
                    {customFields.map((field) => {
                      const ans = selectedRow.customFields?.[field.name];
                      return (
                        <div key={field.name} className="bg-indigo-50/20 p-3 rounded-lg border border-indigo-100">
                          <span className="text-[10px] font-bold text-indigo-900 uppercase tracking-widest block">{field.name}</span>
                          <span className="text-[9px] text-slate-400 block mb-1 font-mono">Instruction rule: {field.prompt}</span>
                          <span className="text-xs text-slate-800 font-semibold leading-relaxed bg-white border border-indigo-100 p-2.5 rounded-md block mt-1">
                            {ans || <span className="italic text-slate-400 font-normal">Pending harvest</span>}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

            </div>

            {/* Footer and controls */}
            <div className="mt-8 pt-4 border-t border-slate-200 flex items-center justify-between shrink-0">
              <span className="text-[10px] text-slate-450 font-mono tracking-widest">SECURE WORKSPACE</span>
              <button
                onClick={() => setSelectedRow(null)}
                className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded-lg text-xs cursor-pointer shadow-sm active:scale-95 transition-all"
              >
                Close Drawer
              </button>
            </div>
          </div>
        </section>
      )}

      {/* -------------------------------------------------------------
          Global footer block
         ------------------------------------------------------------- */}
      <footer className="bg-[#f8fafc] border-t border-slate-200 py-5 px-6 mt-12 transition-all">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row sm:items-center sm:justify-between text-xs text-slate-500 gap-3">
          <div className="flex items-center gap-1.5 text-slate-600">
            <span>Powered by</span>
            <span className="font-semibold text-slate-900 inline-flex items-center gap-1 bg-white border border-slate-200 px-2 py-0.5 rounded shadow-3xs">
              <Sparkles className="w-3.5 h-3.5 text-indigo-500" />
              Gemini AI models
            </span>
            <span>&amp; Google Search Grounding Fallback</span>
          </div>
          <div className="font-mono text-[10px] text-slate-400">
            © {new Date().getFullYear()} Bulk Company Classifier • Secure Workspace Node
          </div>
        </div>
      </footer>
    </div>
  );
}
