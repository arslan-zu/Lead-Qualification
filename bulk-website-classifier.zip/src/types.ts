export type RowStatus = "idle" | "processing" | "completed" | "failed";

export interface CompanyRow {
  id: string;
  name: string;
  website: string;
  status: RowStatus;
  error?: string | null;
  
  // Enriched parameters from server
  enrichedName?: string;
  enrichedWebsite?: string;
  industry?: string;
  subIndustry?: string;
  description?: string;
  stageOrSize?: string;
  targetAudience?: string;
  mainProduct?: string;
  techStackTags?: string[];
  pricingModel?: string;
  confidenceScore?: number;
  
  // Custom metadata variables
  customFields?: Record<string, string>; // mapping from column/field name to AI answered value
  
  // Logs & Scraping status reports
  scrapeReport?: {
    attempted: boolean;
    directScrapeOk: boolean;
    directTitle: string;
    directError?: string | null;
  } | null;
}

export interface CustomFieldConfig {
  name: string;
  prompt: string;
}

export interface DeploymentConfig {
  concurrency: number;
  customInstructions: string;
  customFields: CustomFieldConfig[];
}
